cha(art, bob).
cha(art, bud).
cha(bob,cal).
cha(bob,coe).

ongnoi(X,Y):- cha(X,Z),cha(Z,Y).
