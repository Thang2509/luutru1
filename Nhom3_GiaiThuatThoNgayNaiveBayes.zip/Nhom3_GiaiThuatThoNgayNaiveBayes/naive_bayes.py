
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report

data = pd.read_csv("train.csv")
print(data.head())

print("=== Thông tin tổng quan dữ liệu ===")
print(data.info())

print("\n=== 5 dòng dữ liệu đầu tiên ===")
print(data.head())

print("\n=== Thống kê mô tả ===")
print(data.describe())

features = ['Survived', 'Pclass', 'Sex', 'Age', 'SibSp', 'Parch', 'Fare', 'Embarked']
data = data[features]

data['Age'] = data['Age'].fillna(data['Age'].mean())
data['Embarked'] = data['Embarked'].fillna(data['Embarked'].mode()[0])

data['Sex'] = data['Sex'].map({'male': 0, 'female': 1})
data['Embarked'] = data['Embarked'].map({'S': 0, 'C': 1, 'Q': 2})

print("\n=== Dữ liệu sau tiền xử lý ===")
print(data.head())

X = data.drop('Survived', axis=1)
y = data['Survived']
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

model = GaussianNB()
model.fit(X_train, y_train)

y_pred = model.predict(X_test)

print("\n========== KẾT QUẢ ĐÁNH GIÁ ==========")

accuracy = accuracy_score(y_test, y_pred)
print(f"Accuracy: {accuracy:.4f}")

print("\nConfusion Matrix:")
print(confusion_matrix(y_test, y_pred))

print("\nClassification Report:")
print(classification_report(y_test, y_pred))


new_passenger = pd.DataFrame([{
    'Pclass': 3,
    'Sex': 0,
    'Age': 30,
    'SibSp': 0,
    'Parch': 0,
    'Fare': 7.25,
    'Embarked': 0
}])

prediction = model.predict(new_passenger)

print("\n=== KẾT QUẢ DỰ ĐOÁN ===")
if prediction[0] == 1:
    print("→ Hành khách CÓ KHẢ NĂNG SỐNG SÓT")
else:
    print("→ Hành khách KHÔNG SỐNG SÓT")


survived_count = (y_pred == 1).sum()
not_survived_count = (y_pred == 0).sum()

labels = ['Không sống sót', 'Sống sót']
values = [not_survived_count, survived_count]

plt.figure(figsize=(6, 4))
plt.bar(labels, values)

plt.title('Phân bố kết quả dự đoán - Naive Bayes')
plt.xlabel('Trạng thái')
plt.ylabel('Số lượng')

for i, v in enumerate(values):
    plt.text(i, v + 1, str(v), ha='center')

plt.tight_layout()
plt.show()